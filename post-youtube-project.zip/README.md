# POST-YOUTUBE
Sistema Flask para baixar, cortar e preparar vídeos para upload automatizado.
Endpoint: POST /webhook
Payload: {"video_url": "URL do vídeo"}